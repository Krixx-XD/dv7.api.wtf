{(return(function(...)}local S = {'setmetatble'}{(...)}
    end
  end
end 
{(return(function(...)}local P={'getmetatable'}{(...)}
    end
  end
end
